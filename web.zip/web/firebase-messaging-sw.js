importScripts("https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/8.10.0/firebase-messaging.js");

firebase.initializeApp({
    appId: "1:171558287208:web:5fa363af2dda9eb44488dd",
    apiKey: "AIzaSyDQ_dboirIGb28hskD9xmOQo8kCNPS5zj8",
    authDomain: "fir-2406c.firebaseapp.com",
    databaseURL: "https://fir-2406c-default-rtdb.firebaseio.com",
    projectId: "fir-2406c",
    storageBucket: "fir-2406c.firebasestorage.app",
    messagingSenderId: "171558287208",
});
// Necessary to receive background messages:
var messaging = firebase.messaging();

// // Optional:
// messaging.onBackgroundMessage((m) => {
//     console.log("onBackgroundMessage", m);
// });
messaging.onBackgroundMessage(messaging, (payload) => {
    console.log('[firebase-messaging-sw.js] Received background message ', payload);
    // Customize notification here
    var notificationTitle = 'Background Message Title';
    var notificationOptions = {
        body: 'Background Message body.',
        icon: '/firebase-logo.png'
    };

    self.registration.showNotification(notificationTitle,
        notificationOptions);
});
